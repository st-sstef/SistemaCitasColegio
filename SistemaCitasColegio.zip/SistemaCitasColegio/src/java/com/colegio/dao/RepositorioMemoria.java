package com.colegio.dao;

import com.colegio.model.*;
import java.util.ArrayList;
import java.util.List;

public class RepositorioMemoria {
    private static RepositorioMemoria instancia;
    
    private final List<Usuario> usuarios = new ArrayList<>();
    private final List<PadreFamilia> padres = new ArrayList<>();
    private final List<AsesorAdmisiones> asesores = new ArrayList<>();
    private final List<Cita> citas = new ArrayList<>();
    private final List<Seguimiento> seguimientos = new ArrayList<>();

    private RepositorioMemoria() {
        // Datos iniciales de demostración
        usuarios.add(new Usuario("U1", "Admin Colegio", "admin@colegio.edu", "admin123", "ADMIN", true));
        usuarios.add(new Usuario("U2", "María Asesora", "maria@colegio.edu", "asesor123", "ASESOR", true));

        padres.add(new PadreFamilia("P001", "Juan Pérez", "5555-0101", "juan@gmail.com", "Primaria", "ACTIVO"));
        padres.add(new PadreFamilia("P002", "Ana Gómez", "5555-0202", "ana@gmail.com", "Preprimaria", "ACTIVO"));

        asesores.add(new AsesorAdmisiones("A001", "Licda. María López", "Recorridos y Primaria", true));
        asesores.add(new AsesorAdmisiones("A002", "Lic. Carlos Ruiz", "Admisiones Preprimaria", true));
    }

    public static synchronized RepositorioMemoria getInstancia() {
        if (instancia == null) {
            instancia = new RepositorioMemoria();
        }
        return instancia;
    }

    public List<Usuario> getUsuarios() { return usuarios; }
    public List<PadreFamilia> getPadres() { return padres; }
    public List<AsesorAdmisiones> getAsesores() { return asesores; }
    public List<Cita> getCitas() { return citas; }
    public List<Seguimiento> getSeguimientos() { return seguimientos; }
}