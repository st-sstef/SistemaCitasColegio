package com.colegio.controller;

import com.colegio.dao.RepositorioMemoria;
import com.colegio.model.Usuario;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String correo = request.getParameter("correo");
        String password = request.getParameter("password");

        Usuario usuarioEncontrado = null;
        for (Usuario u : RepositorioMemoria.getInstancia().getUsuarios()) {
            if (u.getCorreo().equalsIgnoreCase(correo) && u.getPassword().equals(password)) {
                usuarioEncontrado = u;
                break;
            }
        }

        if (usuarioEncontrado != null) {
         HttpSession session = request.getSession();
    session.setAttribute("usuarioLogueado", usuarioEncontrado);
    response.sendRedirect("dashboard.jsp");
} else {
            request.setAttribute("error", "Correo o contraseña incorrectos.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}