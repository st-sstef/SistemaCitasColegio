package com.colegio.controller;

import com.colegio.exception.CitaNoEncontradaException;
import com.colegio.exception.EstadoCitaInvalidoException;
import com.colegio.exception.FechaInvalidaException;
import com.colegio.exception.HorarioNoDisponibleException;
import com.colegio.model.*;
import com.colegio.service.CitaService;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet(name = "CitaServlet", urlPatterns = {"/CitaServlet"})
public class CitaServlet extends HttpServlet {

    private final CitaService citaService = new CitaService();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String accion = request.getParameter("accion");

        try {
            if ("crear".equals(accion)) {
                String codigo = "C" + (citaService.getTodasCitas().size() + 1);
                String codPadre = request.getParameter("codPadre");
                String codAsesor = request.getParameter("codAsesor");
                LocalDate fecha = LocalDate.parse(request.getParameter("fecha"));
                LocalTime hora = LocalTime.parse(request.getParameter("hora"));
                String motivo = request.getParameter("motivo");

                PadreFamilia padre = citaService.getTodosPadres().stream().filter(p -> p.getCodigo().equals(codPadre)).findFirst().orElse(null);
                AsesorAdmisiones asesor = citaService.getTodosAsesores().stream().filter(a -> a.getCodigo().equals(codAsesor)).findFirst().orElse(null);

                Cita nuevaCita = new Cita(codigo, padre, asesor, fecha, hora, motivo, "PROGRAMADA");
                citaService.agendarCita(nuevaCita);
                request.setAttribute("mensajeExito", "Cita programada exitosamente.");

            } else if ("cancelar".equals(accion)) {
                String codCita = request.getParameter("codCita");
                citaService.cancelarCita(codCita);
                request.setAttribute("mensajeExito", "Cita cancelada.");

            } else if ("atender".equals(accion)) {
                String codCita = request.getParameter("codCita");
                citaService.atenderCita(codCita);
                request.setAttribute("mensajeExito", "Cita marcada como ATENDIDA.");
            }
        } catch (CitaNoEncontradaException e) {
            request.setAttribute("mensajeError", e.getMessage());
        } catch (EstadoCitaInvalidoException e) {
            request.setAttribute("mensajeError", e.getMessage());
        } catch (FechaInvalidaException e) {
            request.setAttribute("mensajeError", e.getMessage());
        } catch (HorarioNoDisponibleException e) {
            request.setAttribute("mensajeError", e.getMessage());
        }

        request.getRequestDispatcher("citas.jsp").forward(request, response);
    }
}