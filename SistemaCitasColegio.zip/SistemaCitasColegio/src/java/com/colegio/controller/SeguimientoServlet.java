package com.colegio.controller;

import com.colegio.exception.CitaNoEncontradaException;
import com.colegio.exception.EstadoCitaInvalidoException;
import com.colegio.model.*;
import com.colegio.service.CitaService;
import java.io.IOException;
import java.time.LocalDate;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet(name = "SeguimientoServlet", urlPatterns = {"/SeguimientoServlet"})
public class SeguimientoServlet extends HttpServlet {

    private final CitaService citaService = new CitaService();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            String codCita = request.getParameter("codCita");
            String observaciones = request.getParameter("observaciones");
            String recomendaciones = request.getParameter("recomendaciones");
            String proximaAccion = request.getParameter("proximaAccion");

            Cita cita = citaService.buscarPorCodigo(codCita);
            String codSeg = "S" + (citaService.getTodosSeguimientos().size() + 1);

            Seguimiento seg = new Seguimiento(codSeg, cita, LocalDate.now(), observaciones, recomendaciones, proximaAccion);
            citaService.registrarSeguimiento(seg);

            request.setAttribute("mensajeExito", "Seguimiento registrado exitosamente.");
        } catch (CitaNoEncontradaException e) {
            request.setAttribute("mensajeError", e.getMessage());
        } catch (EstadoCitaInvalidoException e) {
            request.setAttribute("mensajeError", e.getMessage());
        }

        request.getRequestDispatcher("seguimiento.jsp").forward(request, response);
    }
}