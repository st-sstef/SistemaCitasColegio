package com.colegio.service;

import com.colegio.dao.RepositorioMemoria;
import com.colegio.exception.*;
import com.colegio.model.*;
import java.time.LocalDate;
import java.util.List;

public class CitaService {

    private final RepositorioMemoria repo = RepositorioMemoria.getInstancia();

    /**
     * CONTRATO 1: agendarCita
     * PRECONDICIÓN: cita != null, padre != null, asesor != null, fecha >= hoy, horario libre
     * POSTCONDICIÓN: Cita registrada con estado "PROGRAMADA"
     * @param cita
     * @throws com.colegio.exception.FechaInvalidaException
     * @throws com.colegio.exception.HorarioNoDisponibleException
     */
    public void agendarCita(Cita cita) throws FechaInvalidaException, HorarioNoDisponibleException {
        if (cita == null || cita.getPadre() == null || cita.getAsesor() == null) {
            throw new IllegalArgumentException("Datos de la cita incompletos.");
        }
        if (cita.getFecha().isBefore(LocalDate.now())) {
            throw new FechaInvalidaException("No se pueden programar citas en fechas anteriores a la actual.");
        }
        for (Cita c : repo.getCitas()) {
            if (c.getAsesor().getCodigo().equals(cita.getAsesor().getCodigo()) &&
                c.getFecha().equals(cita.getFecha()) &&
                c.getHora().equals(cita.getHora()) &&
                !c.getEstado().equals("CANCELADA")) {
                throw new HorarioNoDisponibleException("El asesor ya posee una cita agendada en esa fecha y hora.");
            }
        }
        cita.setEstado("PROGRAMADA");
        repo.getCitas().add(cita);
    }

    /**
     * CONTRATO 2: cancelarCita
     * PRECONDICIÓN: Cita existe y no fue ATENDIDA
     * POSTCONDICIÓN: Estado cambia a "CANCELADA"
     */
    public void cancelarCita(String codigoCita) throws CitaNoEncontradaException, EstadoCitaInvalidoException {
        Cita cita = buscarPorCodigo(codigoCita);
        if (cita.getEstado().equals("ATENDIDA")) {
            throw new EstadoCitaInvalidoException("No se puede cancelar una cita que ya fue atendida.");
        }
        cita.setEstado("CANCELADA");
    }

    /**
     * CONTRATO 3: atenderCita
     * PRECONDICIÓN: Cita existe y NO está CANCELADA
     * POSTCONDICIÓN: Estado cambia a "ATENDIDA"
     */
    public void atenderCita(String codigoCita) throws CitaNoEncontradaException, EstadoCitaInvalidoException {
        Cita cita = buscarPorCodigo(codigoCita);
        if (cita.getEstado().equals("CANCELADA")) {
            throw new EstadoCitaInvalidoException("Una cita cancelada no puede ser atendida.");
        }
        cita.setEstado("ATENDIDA");
    }

    /**
     * CONTRATO 4: registrarSeguimiento
     * PRECONDICIÓN: Cita existe y está en estado "ATENDIDA"
     * POSTCONDICIÓN: Registra el seguimiento exitosamente
     */
    public void registrarSeguimiento(Seguimiento seg) throws CitaNoEncontradaException, EstadoCitaInvalidoException {
        if (seg == null || seg.getCitaRelacionada() == null) {
            throw new IllegalArgumentException("Seguimiento inválido.");
        }
        Cita cita = buscarPorCodigo(seg.getCitaRelacionada().getCodigo());
        if (!cita.getEstado().equals("ATENDIDA")) {
            throw new EstadoCitaInvalidoException("Solo una cita ATENDIDA puede recibir seguimiento.");
        }
        repo.getSeguimientos().add(seg);
    }

    public Cita buscarPorCodigo(String codigo) throws CitaNoEncontradaException {
        for (Cita c : repo.getCitas()) {
            if (c.getCodigo().equalsIgnoreCase(codigo)) return c;
        }
        throw new CitaNoEncontradaException("La cita con código " + codigo + " no fue encontrada.");
    }

    public List<Cita> getTodasCitas() { return repo.getCitas(); }
    public List<Seguimiento> getTodosSeguimientos() { return repo.getSeguimientos(); }
    public List<PadreFamilia> getTodosPadres() { return repo.getPadres(); }
    public List<AsesorAdmisiones> getTodosAsesores() { return repo.getAsesores(); }
}