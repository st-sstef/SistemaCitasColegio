package com.colegio.service;

public interface Notificable {
    void enviarNotificacion(String destinatario, String mensaje);
}