package com.colegio.service;

public class NotificacionCorreo implements Notificable {
    @Override
    public void enviarNotificacion(String destinatario, String mensaje) {
        System.out.println(" Enviando Correo a " + destinatario + ": " + mensaje);
    }
}