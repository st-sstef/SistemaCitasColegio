package com.colegio.exception;

public class EstadoCitaInvalidoException extends Exception {
    public EstadoCitaInvalidoException(String msg) { super(msg); }
}