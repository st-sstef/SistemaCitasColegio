package com.colegio.exception;

public class CitaNoEncontradaException extends Exception {
    public CitaNoEncontradaException(String msg) { super(msg); }
}