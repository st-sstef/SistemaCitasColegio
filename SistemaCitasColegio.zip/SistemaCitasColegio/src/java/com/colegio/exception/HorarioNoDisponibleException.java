package com.colegio.exception;

public class HorarioNoDisponibleException extends Exception {
    public HorarioNoDisponibleException(String msg) {
        super(msg);
    }
}