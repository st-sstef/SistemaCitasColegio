package com.colegio.exception;

public class FechaInvalidaException extends Exception {
    public FechaInvalidaException(String msg) { super(msg); }
}
