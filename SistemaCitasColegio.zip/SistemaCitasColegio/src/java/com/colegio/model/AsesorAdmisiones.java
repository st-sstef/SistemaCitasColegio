package com.colegio.model;

public class AsesorAdmisiones {
    private String codigo;
    private String nombre;
    private String especialidad;
    private boolean disponible;

    public AsesorAdmisiones() {}

    public AsesorAdmisiones(String codigo, String nombre, String especialidad, boolean disponible) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.especialidad = especialidad;
        this.disponible = disponible;
    }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getEspecialidad() { return especialidad; }
    public void setEspecialidad(String especialidad) { this.especialidad = especialidad; }
    public boolean isDisponible() { return disponible; }
    public void setDisponible(boolean disponible) { this.disponible = disponible; }
}