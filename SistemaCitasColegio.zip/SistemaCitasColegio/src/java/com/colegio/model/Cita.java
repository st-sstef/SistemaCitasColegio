package com.colegio.model;

import java.time.LocalDate;
import java.time.LocalTime;

public class Cita {
    private String codigo;
    private PadreFamilia padre;
    private AsesorAdmisiones asesor;
    private LocalDate fecha;
    private LocalTime hora;
    private String motivo;
    private String estado;

    public Cita() {}

    public Cita(String codigo, PadreFamilia padre, AsesorAdmisiones asesor, LocalDate fecha, LocalTime hora, String motivo, String estado) {
        this.codigo = codigo;
        this.padre = padre;
        this.asesor = asesor;
        this.fecha = fecha;
        this.hora = hora;
        this.motivo = motivo;
        this.estado = estado;
    }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public PadreFamilia getPadre() { return padre; }
    public void setPadre(PadreFamilia padre) { this.padre = padre; }
    public AsesorAdmisiones getAsesor() { return asesor; }
    public void setAsesor(AsesorAdmisiones asesor) { this.asesor = asesor; }
    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }
    public LocalTime getHora() { return hora; }
    public void setHora(LocalTime hora) { this.hora = hora; }
    public String getMotivo() { return motivo; }
    public void setMotivo(String motivo) { this.motivo = motivo; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}