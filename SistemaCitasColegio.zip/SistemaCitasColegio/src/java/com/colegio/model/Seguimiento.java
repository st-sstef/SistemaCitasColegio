package com.colegio.model;

import java.time.LocalDate;

public class Seguimiento {
    private String codigo;
    private Cita citaRelacionada;
    private LocalDate fecha;
    private String observaciones;
    private String recomendaciones;
    private String proximaAccion;

    public Seguimiento() {}

    public Seguimiento(String codigo, Cita citaRelacionada, LocalDate fecha, String observaciones, String recomendaciones, String proximaAccion) {
        this.codigo = codigo;
        this.citaRelacionada = citaRelacionada;
        this.fecha = fecha;
        this.observaciones = observaciones;
        this.recomendaciones = recomendaciones;
        this.proximaAccion = proximaAccion;
    }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public Cita getCitaRelacionada() { return citaRelacionada; }
    public void setCitaRelacionada(Cita citaRelacionada) { this.citaRelacionada = citaRelacionada; }
    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }
    public String getObservaciones() { return observaciones; }
    public void setObservaciones(String observaciones) { this.observaciones = observaciones; }
    public String getRecomendaciones() { return recomendaciones; }
    public void setRecomendaciones(String recomendaciones) { this.recomendaciones = recomendaciones; }
    public String getProximaAccion() { return proximaAccion; }
    public void setProximaAccion(String proximaAccion) { this.proximaAccion = proximaAccion; }
}