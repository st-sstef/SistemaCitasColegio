package com.colegio.model;

public class PadreFamilia {
    private String codigo;
    private String nombre;
    private String telefono;
    private String correo;
    private String nivelInteres;
    private String estado;

    public PadreFamilia() {}

    public PadreFamilia(String codigo, String nombre, String telefono, String correo, String nivelInteres, String estado) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.telefono = telefono;
        this.correo = correo;
        this.nivelInteres = nivelInteres;
        this.estado = estado;
    }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }
    public String getNivelInteres() { return nivelInteres; }
    public void setNivelInteres(String nivelInteres) { this.nivelInteres = nivelInteres; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}