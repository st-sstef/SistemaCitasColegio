<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seguimiento de Admisiones - Sistema de Citas</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Poppins', sans-serif; }
        body { background-color: #fff5f8; min-height: 100vh; padding-bottom: 40px; }
        .header-bar {
            background: linear-gradient(135deg, #ec407a 0%, #d81b60 100%);
            color: white; padding: 16px 30px; display: flex;
            justify-content: space-between; align-items: center;
            box-shadow: 0 4px 12px rgba(216, 27, 96, 0.2);
        }
        .header-bar a {
            color: white; text-decoration: none; font-size: 0.9rem;
            background: rgba(255, 255, 255, 0.2); padding: 8px 14px;
            border-radius: 8px; transition: background 0.3s ease;
        }
        .header-bar a:hover { background: rgba(255, 255, 255, 0.35); }
        .container { max-width: 1000px; margin: 30px auto; padding: 0 20px; }
        .form-card, .table-card {
            background: white; padding: 25px; border-radius: 16px;
            box-shadow: 0 8px 20px rgba(216, 112, 147, 0.15);
            border: 1px solid #f8bbd0; margin-bottom: 30px;
        }
        .form-card h3, .table-card h3 { color: #d81b60; margin-bottom: 20px; }
        .form-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 15px; margin-bottom: 15px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; font-size: 0.85rem; color: #880e4f; margin-bottom: 5px; font-weight: 500; }
        .form-group select, .form-group textarea {
            width: 100%; padding: 10px; border: 2px solid #f8bbd0;
            border-radius: 8px; outline: none; background-color: #fff8fa; font-size: 0.9rem;
        }
        .form-group select:focus, .form-group textarea:focus { border-color: #ec407a; background-color: #fff; }
        .btn-save {
            background: linear-gradient(135deg, #ec407a 0%, #d81b60 100%);
            color: white; border: none; padding: 12px 20px; border-radius: 8px;
            font-weight: 600; cursor: pointer; width: 100%; margin-top: 5px;
        }
        table { width: 100%; border-collapse: collapse; text-align: left; }
        th { background-color: #fce4ec; color: #880e4f; padding: 12px; font-size: 0.9rem; }
        td { padding: 12px; border-bottom: 1px solid #f8bbd0; color: #444; font-size: 0.88rem; }
        tr:hover { background-color: #fff8fa; }
        .badge-en-proceso { background-color: #f3e5f5; color: #7b1fa2; padding: 4px 8px; border-radius: 6px; font-size: 0.75rem; font-weight: 600; }
        .badge-completado { background-color: #e8f5e9; color: #2e7d32; padding: 4px 8px; border-radius: 6px; font-size: 0.75rem; font-weight: 600; }
        .badge-cancelado { background-color: #ffebee; color: #c62828; padding: 4px 8px; border-radius: 6px; font-size: 0.75rem; font-weight: 600; }
    </style>
</head>
<body>

    <div class="header-bar">
        <h2>Módulo de Seguimiento</h2>
        <a href="dashboard.jsp">← Volver al Dashboard</a>
    </div>

    <div class="container">
        <!-- Formulario -->
        <div class="form-card">
            <h3>Registrar Avance / Observación</h3>
            <form action="seguimiento.jsp" method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label for="cita">Cita / Postulante</label>
                        <select name="cita" id="cita" required>
                            <option value="">Seleccione una cita...</option>
                            <option value="#101 - Juan Pérez">#101 - Juan Pérez</option>
                            <option value="#102 - Ana Gómez">#102 - Ana Gómez</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="estado">Estado del Proceso</label>
                        <select name="estado" id="estado" required>
                            <option value="EN PROCESO">EN PROCESO</option>
                            <option value="COMPLETADO">COMPLETADO</option>
                            <option value="CANCELADO">CANCELADO</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label for="observacion">Observaciones del Asesor</label>
                    <textarea name="observacion" id="observacion" rows="3" placeholder="Escriba aquí los detalles..." required></textarea>
                </div>

                <button type="submit" class="btn-save">Guardar Seguimiento</button>
            </form>
        </div>

        <!-- Tabla -->
        <div class="table-card">
            <h3>Historial de Evaluaciones</h3>
            <table>
                <thead>
                    <tr>
                        <th>Cita</th>
                        <th>Asesor</th>
                        <th>Observación</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>#101 - Juan Pérez</td>
                        <td>María Asesora</td>
                        <td>Se entregó la ficha de inscripción. Pendiente validar documentos.</td>
                        <td><span class="badge-en-proceso">EN PROCESO</span></td>
                    </tr>
                    <%
                        request.setCharacterEncoding("UTF-8");
                        String citaVal = request.getParameter("cita");
                        String estadoVal = request.getParameter("estado");
                        String obsVal = request.getParameter("observacion");

                        if (citaVal != null && obsVal != null && !obsVal.trim().isEmpty()) {
                            String badgeClass = "badge-en-proceso";
                            if ("COMPLETADO".equals(estadoVal)) badgeClass = "badge-completado";
                            if ("CANCELADO".equals(estadoVal)) badgeClass = "badge-cancelado";
                    %>
                    <tr>
                        <td><%= citaVal %></td>
                        <td>María Asesora</td>
                        <td><%= obsVal %></td>
                        <td><span class="<%= badgeClass %>"><%= estadoVal %></span></td>
                    </tr>
                    <% } %>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>