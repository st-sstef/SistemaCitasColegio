<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Profesionales - Colegio</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Poppins', sans-serif; }
        body { background-color: #fff5f8; padding-bottom: 40px; }
        .header-bar { background: linear-gradient(135deg, #ec407a 0%, #d81b60 100%); color: white; padding: 16px 30px; display: flex; justify-content: space-between; align-items: center; }
        .header-bar a { color: white; text-decoration: none; background: rgba(255,255,255,0.2); padding: 8px 14px; border-radius: 8px; }
        .container { max-width: 1000px; margin: 30px auto; padding: 0 20px; }
        .card { background: white; padding: 25px; border-radius: 16px; border: 1px solid #f8bbd0; margin-bottom: 30px; box-shadow: 0 8px 20px rgba(216,112,147,0.15); }
        .card h3 { color: #d81b60; margin-bottom: 15px; }
        .form-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 15px; }
        input, select { width: 100%; padding: 10px; border: 2px solid #f8bbd0; border-radius: 8px; background: #fff8fa; }
        .btn { background: #d81b60; color: white; border: none; padding: 10px 20px; border-radius: 8px; font-weight: 600; cursor: pointer; width: 100%; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th { background: #fce4ec; color: #880e4f; padding: 10px; text-align: left; }
        td { padding: 10px; border-bottom: 1px solid #f8bbd0; }
    </style>
</head>
<body>
    <div class="header-bar">
        <h2>Gestión de Profesionales / Asesores</h2>
        <a href="dashboard.jsp">← Volver al Dashboard</a>
    </div>
    <div class="container">
        <div class="card">
            <h3>Registrar Profesional</h3>
            <form action="profesionales.jsp" method="POST">
                <div class="form-row">
                    <div><label>Nombre Completo</label><input type="text" name="nombre" required placeholder="Dra. María López"></div>
                    <div><label>Especialidad</label><input type="text" name="especialidad" required placeholder="Admisiones / Psicología"></div>
                    <div><label>Disponibilidad</label><select name="dispo"><option>Mañana</option><option>Tarde</option><option>Tiempo Completo</option></select></div>
                </div>
                <button type="submit" class="btn">Guardar Profesional</button>
            </form>
        </div>
        <div class="card">
            <h3>Lista de Profesionales</h3>
            <table>
                <thead>
                    <tr><th>ID</th><th>Nombre</th><th>Especialidad</th><th>Disponibilidad</th></tr>
                </thead>
                <tbody>
                    <tr><td>A001</td><td>María Asesora</td><td>Admisiones Primaria</td><td>Mañana</td></tr>
                    <%
                        request.setCharacterEncoding("UTF-8");
                        String nom = request.getParameter("nombre");
                        String esp = request.getParameter("especialidad");
                        String dis = request.getParameter("dispo");
                        if (nom != null && esp != null) {
                    %>
                    <tr><td>A00<%= (int)(Math.random()*80 + 2) %></td><td><%= nom %></td><td><%= esp %></td><td><%= dis %></td></tr>
                    <% } %>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>