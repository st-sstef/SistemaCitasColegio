<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Historial General - Colegio</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Poppins', sans-serif; }
        body { background-color: #fff5f8; padding-bottom: 40px; }
        .header-bar { background: linear-gradient(135deg, #ec407a 0%, #d81b60 100%); color: white; padding: 16px 30px; display: flex; justify-content: space-between; align-items: center; }
        .header-bar a { color: white; text-decoration: none; background: rgba(255,255,255,0.2); padding: 8px 14px; border-radius: 8px; }
        .container { max-width: 1000px; margin: 30px auto; padding: 0 20px; }
        .card { background: white; padding: 25px; border-radius: 16px; border: 1px solid #f8bbd0; box-shadow: 0 8px 20px rgba(216,112,147,0.15); }
        .card h3 { color: #d81b60; margin-bottom: 15px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th { background: #fce4ec; color: #880e4f; padding: 10px; text-align: left; }
        td { padding: 10px; border-bottom: 1px solid #f8bbd0; }
        .badge { background: #e8f5e9; color: #2e7d32; padding: 4px 8px; border-radius: 6px; font-size: 0.75rem; font-weight: 600; }
    </style>
</head>
<body>
    <div class="header-bar">
        <h2>Historial Cronológico General</h2>
        <a href="dashboard.jsp">← Volver al Dashboard</a>
    </div>
    <div class="container">
        <div class="card">
            <h3>Registro Unificado de Citas y Evaluaciones</h3>
            <table>
                <thead>
                    <tr><th>Fecha</th><th>Padre / Paciente</th><th>Atendido por</th><th>Acción / Observación</th><th>Estado</th></tr>
                </thead>
                <tbody>
                    <tr><td>2026-10-15</td><td>Juan Pérez</td><td>María Asesora</td><td>Entrega de ficha técnica</td><td><span class="badge">COMPLETADO</span></td></tr>
                    <tr><td>2026-10-16</td><td>Ana Gómez</td><td>María Asesora</td><td>Entrevista psicológica programada</td><td><span class="badge">EN PROCESO</span></td></tr>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>