<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Citas - Sistema de Citas</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Poppins', sans-serif; }
        body { background-color: #fff5f8; min-height: 100vh; padding-bottom: 40px; }
        .header-bar {
            background: linear-gradient(135deg, #ec407a 0%, #d81b60 100%);
            color: white; padding: 16px 30px; display: flex;
            justify-content: space-between; align-items: center;
            box-shadow: 0 4px 12px rgba(216, 27, 96, 0.2);
        }
        .header-bar a {
            color: white; text-decoration: none; font-size: 0.9rem;
            background: rgba(255, 255, 255, 0.2); padding: 8px 14px;
            border-radius: 8px; transition: background 0.3s ease;
        }
        .header-bar a:hover { background: rgba(255, 255, 255, 0.35); }
        .container { max-width: 1000px; margin: 30px auto; padding: 0 20px; }
        .form-card, .table-card {
            background: white; padding: 25px; border-radius: 16px;
            box-shadow: 0 8px 20px rgba(216, 112, 147, 0.15);
            border: 1px solid #f8bbd0; margin-bottom: 30px;
        }
        .form-card h3, .table-card h3 { color: #d81b60; margin-bottom: 20px; }
        .form-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 15px; }
        .form-group label { display: block; font-size: 0.85rem; color: #880e4f; margin-bottom: 5px; font-weight: 500; }
        .form-group input, .form-group select {
            width: 100%; padding: 10px; border: 2px solid #f8bbd0;
            border-radius: 8px; outline: none; background-color: #fff8fa; font-size: 0.9rem;
        }
        .form-group input:focus, .form-group select:focus { border-color: #ec407a; background-color: #fff; }
        .btn-save {
            background: linear-gradient(135deg, #ec407a 0%, #d81b60 100%);
            color: white; border: none; padding: 12px 20px; border-radius: 8px;
            font-weight: 600; cursor: pointer; width: 100%; margin-top: 10px;
        }
        table { width: 100%; border-collapse: collapse; text-align: left; }
        th { background-color: #fce4ec; color: #880e4f; padding: 12px; font-size: 0.9rem; }
        td { padding: 12px; border-bottom: 1px solid #f8bbd0; color: #444; font-size: 0.88rem; }
        tr:hover { background-color: #fff8fa; }
        .badge-pendiente { background-color: #ffe0b2; color: #e65100; padding: 4px 8px; border-radius: 6px; font-size: 0.75rem; font-weight: 600; }
    </style>
</head>
<body>

    <div class="header-bar">
        <h2>Módulo de Citas</h2>
        <a href="dashboard.jsp">← Volver al Dashboard</a>
    </div>

    <div class="container">
        <div class="form-card">
            <h3>Agendar Nueva Cita</h3>
            <form action="citas.jsp" method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label for="padre">Padre de Familia</label>
                        <select name="padre" id="padre" required>
                            <option value="">-- Seleccione un Padre --</option>
                            <option value="Juan Pérez">Juan Pérez (Primaria)</option>
                            <option value="Ana Gómez">Ana Gómez (Preprimaria)</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="fecha">Fecha</label>
                        <input type="date" id="fecha" name="fecha" required>
                    </div>

                    <div class="form-group">
                        <label for="hora">Hora</label>
                        <input type="time" id="hora" name="hora" required>
                    </div>
                </div>

                <button type="submit" class="btn-save">Guardar Cita</button>
            </form>
        </div>

        <div class="table-card">
            <h3>Lista de Citas Programadas</h3>
            <table>
                <thead>
                    <tr>
                        <th>ID Cita</th>
                        <th>Padre de Familia</th>
                        <th>Fecha</th>
                        <th>Hora</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>#101</td>
                        <td>Juan Pérez</td>
                        <td>2026-10-15</td>
                        <td>10:00 AM</td>
                        <td><span class="badge-pendiente">PENDIENTE</span></td>
                    </tr>
                    <tr>
                        <td>#102</td>
                        <td>Ana Gómez</td>
                        <td>2026-10-16</td>
                        <td>11:30 AM</td>
                        <td><span class="badge-pendiente">PENDIENTE</span></td>
                    </tr>
                    <%
                        request.setCharacterEncoding("UTF-8");
                        String padreNom = request.getParameter("padre");
                        String fechaVal = request.getParameter("fecha");
                        String horaVal = request.getParameter("hora");

                        if (padreNom != null && !padreNom.trim().isEmpty() && fechaVal != null && horaVal != null) {
                    %>
                    <tr>
                        <td>#<%= (int)(Math.random() * 800 + 103) %></td>
                        <td><%= padreNom %></td>
                        <td><%= fechaVal %></td>
                        <td><%= horaVal %></td>
                        <td><span class="badge-pendiente">PENDIENTE</span></td>
                    </tr>
                    <% } %>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>