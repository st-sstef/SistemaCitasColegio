<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Principal - Sistema Citas Colegio</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background-color: #fff5f8;
            min-height: 100vh;
            padding-bottom: 40px;
        }

        .header-bar {
            background: linear-gradient(135deg, #ec407a 0%, #d81b60 100%);
            color: white;
            padding: 20px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 12px rgba(216, 27, 96, 0.2);
        }

        .header-bar h1 {
            font-size: 1.5rem;
            font-weight: 600;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .btn-logout {
            color: #d81b60;
            background-color: white;
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 600;
            padding: 8px 16px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .btn-logout:hover {
            background-color: #fce4ec;
            transform: translateY(-2px);
        }

        .container {
            max-width: 1100px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .welcome-card {
            background: white;
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(216, 112, 147, 0.15);
            border: 1px solid #f8bbd0;
            margin-bottom: 35px;
        }

        .welcome-card h2 {
            color: #d81b60;
            margin-bottom: 8px;
            font-size: 1.6rem;
        }

        .welcome-card p {
            color: #666;
            font-size: 0.95rem;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 35px;
        }

        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            border-left: 5px solid #ec407a;
            box-shadow: 0 4px 12px rgba(216, 112, 147, 0.1);
        }

        .stat-card h4 {
            color: #880e4f;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .stat-card p {
            color: #d81b60;
            font-size: 1.8rem;
            font-weight: 700;
            margin-top: 5px;
        }

        .section-title {
            color: #880e4f;
            font-size: 1.2rem;
            margin-bottom: 20px;
            font-weight: 600;
        }

        .modules-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
        }

        .module-card {
            background: white;
            padding: 25px;
            border-radius: 16px;
            border: 1px solid #f8bbd0;
            box-shadow: 0 6px 16px rgba(216, 112, 147, 0.12);
            transition: all 0.3s ease;
            text-decoration: none;
            color: inherit;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .module-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 24px rgba(216, 27, 96, 0.2);
            border-color: #ec407a;
        }

        .module-card h3 {
            color: #d81b60;
            font-size: 1.1rem;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .module-card p {
            color: #666;
            font-size: 0.85rem;
            line-height: 1.4;
            margin-bottom: 20px;
        }

        .module-link {
            color: #ec407a;
            font-weight: 600;
            font-size: 0.85rem;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .badge-role {
            background-color: rgba(255, 255, 255, 0.25);
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.75rem;
        }
    </style>
</head>
<body>

    <!-- Header / Barra Superior -->
    <div class="header-bar">
        <h1>Sistema Citas Colegio</h1>
        <div class="user-info">
            <span class="badge-role">Rol: Administrador / Asesor</span>
            <a href="login.jsp" class="btn-logout">Cerrar Sesión</a>
        </div>
    </div>

    <div class="container">
        <!-- Tarjeta de Bienvenida -->
        <div class="welcome-card">
            <h2>¡Bienvenido al Panel Principal! </h2>
            <p>Gestiona el flujo completo de solicitudes, registros de familias, citas de admisión y seguimiento cronológico del colegio.</p>
        </div>

        <!-- Indicadores Básicos (Módulo 07) -->
        <div class="stats-grid">
            <div class="stat-card">
                <h4>Padres Registrados</h4>
                <p>2</p>
            </div>
            <div class="stat-card">
                <h4>Asesores Activos</h4>
                <p>1</p>
            </div>
            <div class="stat-card">
                <h4>Citas Programadas</h4>
                <p>2</p>
            </div>
            <div class="stat-card">
                <h4>Evaluaciones</h4>
                <p>1</p>
            </div>
        </div>

        <!-- Módulos de Trabajo Obligatorios -->
        <h3 class="section-title">Módulos del Sistema</h3>
        <div class="modules-grid">

            <!-- Módulo 02: Padres -->
            <a href="pacientes.jsp" class="module-card">
                <div>
                    <h3>Padres </h3>
                    <p>Registro, consulta y actualización de datos de los padres de familia y postulantes.</p>
                </div>
                <span class="module-link">Gestionar Pacientes →</span>
            </a>

            <!-- Módulo 03: Profesionales / Asesores -->
            <a href="profesionales.jsp" class="module-card">
                <div>
                    <h3>Profesionales</h3>
                    <p>Gestión de asesores de admisión, especialidad y horarios de disponibilidad.</p>
                </div>
                <span class="module-link">Gestionar Asesores →</span>
            </a>

            <!-- Módulo 04: Agenda de Citas -->
            <a href="citas.jsp" class="module-card">
                <div>
                    <h3>Agenda de Citas</h3>
                    <p>Programar, confirmar, cancelar y gestionar la atención de citas de admisión.</p>
                </div>
                <span class="module-link">Ir a la Agenda →</span>
            </a>

            <!-- Módulo 05: Seguimiento -->
            <a href="seguimiento.jsp" class="module-card">
                <div>
                    <h3>Seguimiento</h3>
                    <p>Registro de observaciones, estado de admisión, recomendaciones y próximas acciones.</p>
                </div>
                <span class="module-link">Ver Seguimiento →</span>
            </a>

            <!-- Módulo 06: Historial Cronológico -->
            <a href="historial.jsp" class="module-card">
                <div>
                    <h3>Historial General</h3>
                    <p>Consulta consolidada e historial de todas las citas y evaluaciones registradas.</p>
                </div>
                <span class="module-link">Ver Historial →</span>
            </a>

        </div>
    </div>

</body>
</html>